//
//  ViewController.swift
//  Exam1_54011212057
//
//  Created by student on 12/17/14.
//  Copyright (c) 2014 student. All rights reserved.
//

import UIKit
import CoreData

class ViewController: UIViewController {
    var items = [NSManagedObject]()

    @IBOutlet var name: UITextField!
    
    @IBOutlet var amount: UITextField!
    
    @IBOutlet var price: UITextField!
    
    
    @IBOutlet var outName: UILabel!
    
    @IBOutlet var outAmout: UILabel!
    
    @IBOutlet var outPrice: UILabel!
    
    @IBAction func done(sender: AnyObject) {
        name.text = outName.text
        amount.text = outAmout.text
        price.text = outPrice.text
        
        var alert = UIAlertController(title: "New Stocks", message: "Save Stocks OK", preferredStyle: .Alert)
        
        let saveAction = UIAlertAction(title: "SaveOk", style: .Default, handler: nil)
        
        
        alert.addAction(saveAction)
        
        presentViewController(alert,
            animated: true,
            completion: nil)
    }
    func saveStock(stock: String){
        let appDelegate =
        UIApplication.sharedApplication().delegate as AppDelegate
        
        let managedContext = appDelegate.managedObjectContext!
        
        let entity = NSEntityDescription.entityForName("Stock", inManagedObjectContext: managedContext)
        
        let item = NSManagedObject(entity: entity!, insertIntoManagedObjectContext: managedContext)
        
        item.setValue(name, forKey: "name")
        
        var error: NSError?
        if !managedContext.save(&error){
            println("Could not save\(error),\(error?.userInfo)")
        }
        items.append(item)
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }



}

